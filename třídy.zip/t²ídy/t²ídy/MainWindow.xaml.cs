﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace třídy
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
   
    
        public partial class MainWindow : Window
        {
            private List<Zvire> seznamZvirat;

            public MainWindow()
            {
                InitializeComponent();
                seznamZvirat = new List<Zvire>
            {
                new Pes(),
                new Ptak(),
                new Ryba()
            };
                foreach (var zvire in seznamZvirat)
                {
                    listBoxZvirata.Items.Add(zvire);
                }
            }

        private void listBoxZvirata_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (listBoxZvirata.SelectedItem != null)
            {
                Zvire zvire = (Zvire)listBoxZvirata.SelectedItem;
                ZobrazInformaceOZvire(zvire);
            }
        }

        private void ZobrazInformaceOZvire(Zvire zvire)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Zvíře: {zvire.GetType().Name}");
            sb.AppendLine($"Počet nohou: {zvire.PocetNohou}");
            if(zvire.UmiLetat== true)
            { sb.AppendLine($"Umí létat: Ano "); }
            else 
            { sb.AppendLine($"Umí létat: ne"); }
            sb.AppendLine($"Barva: {zvire.Barva}");
            sb.AppendLine($"Zvuk: {zvire.VydejZvuk()}");
            textBlockZvirata.Text = sb.ToString();
        }
    }
    
}
