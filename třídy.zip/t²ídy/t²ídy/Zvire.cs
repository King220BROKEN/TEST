﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace třídy
{
   
    
        public class Zvire
        {
        private string barva;

        public int PocetNohou { get; set; }
        public bool UmiLetat { get; set; }
        public string Barva { get; set; }
        

        public virtual string VydejZvuk()
            {
                return "Neznámý zvuk";
            }
        }

        public class Pes : Zvire
        {
            public Pes()
            {
                PocetNohou = 4;
                UmiLetat = false;
                Barva = "Hnědá";
            }

            public override string VydejZvuk()
            {
                return "Pes štěká";
            }
        }

        public class Ptak : Zvire
        {
            public Ptak()
            {
                PocetNohou = 2;
                UmiLetat = true;
                Barva = "Modrá";
            }

            public override string VydejZvuk()
            {
                return "Pták píská";
            }
        }

        public class Ryba : Zvire
        {
            public Ryba()
            {
                PocetNohou = 0;
                UmiLetat = false;
                Barva = "Zlatá";
            }

            public override string VydejZvuk()
            {
                return "Ryba mlaská";
            }
        }
    }

